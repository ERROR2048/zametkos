// Практическая работа №2 (доработанная) — «Заметки»
//
// Реализовано:
//   • onTap        — открывает заметку для просмотра полного текста;
//   • onDoubleTap  — отмечает / снимает «важную» заметку (⭐️ + цвет карточки);
//   • onLongPress  — открывает редактирование, после сохранения текст обновляется;
//   • свайп влево  — удаляет заметку из списка;
//   • свайп вправо — возвращает заметке обычный статус.
//
// Базовый функционал (ввод текста, кнопка «Сохранить», список, удаление,
// редактирование) сохранён и продублирован кнопками на экране просмотра.

import 'package:flutter/material.dart';

void main() => runApp(const NotesApp());

/// Модель одной заметки.
class Note {
  final int id;
  String text;
  bool isImportant;
  final DateTime createdAt;

  Note({
    required this.id,
    required this.text,
    this.isImportant = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();
}

/// Форматирование даты без внешних пакетов (без intl).
String _formatDate(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(d.day)}.${two(d.month)}.${d.year}  '
      '${two(d.hour)}:${two(d.minute)}';
}

class NotesApp extends StatelessWidget {
  const NotesApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Заметки',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      home: const NotesHomePage(),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Главный экран: поле ввода, кнопка «Сохранить», список заметок
// ─────────────────────────────────────────────────────────────────────────────
class NotesHomePage extends StatefulWidget {
  const NotesHomePage({Key? key}) : super(key: key);

  @override
  State<NotesHomePage> createState() => _NotesHomePageState();
}

class _NotesHomePageState extends State<NotesHomePage> {
  final TextEditingController _inputController = TextEditingController();
  final List<Note> _notes = <Note>[];
  int _nextId = 1;

  @override
  void dispose() {
    _inputController.dispose();
    super.dispose();
  }

  void _showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(text),
          duration: const Duration(seconds: 2),
        ),
      );
  }

  // ===== Базовый функционал: сохранение новой заметки =====
  void _addNote() {
    final String text = _inputController.text.trim();
    if (text.isEmpty) {
      _showMessage('Введите текст заметки');
      return;
    }
    setState(() {
      _notes.insert(0, Note(id: _nextId++, text: text));
    });
    _inputController.clear();
    FocusScope.of(context).unfocus();
    _showMessage('Заметка сохранена');
  }

  // ===== onTap: просмотр полного текста =====
  Future<void> _openNote(Note note) async {
    final String? result = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        builder: (BuildContext ctx) => NoteViewPage(note: note),
      ),
    );
    if (!mounted) return;
    // Кнопки на экране просмотра дублируют жесты (базовая оценка 5).
    if (result == 'edit') {
      await _editNote(note);
    } else if (result == 'delete') {
      _deleteNote(note);
    }
  }

  // ===== onDoubleTap: пометка «важная» =====
  void _toggleImportant(Note note) {
    setState(() {
      note.isImportant = !note.isImportant;
    });
    _showMessage(
      note.isImportant
          ? 'Заметка отмечена как важная ⭐️'
          : 'Отметка «важная» снята',
    );
  }

  // ===== Свайп вправо: восстановление обычного статуса =====
  void _resetImportant(Note note) {
    if (!note.isImportant) {
      _showMessage('Заметка уже имеет обычный статус');
      return;
    }
    setState(() {
      note.isImportant = false;
    });
    _showMessage('Восстановлен обычный статус заметки');
  }

  // ===== onLongPress: редактирование с обновлением текста =====
  Future<void> _editNote(Note note) async {
    final String? newText = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        builder: (BuildContext ctx) => EditNotePage(initialText: note.text),
      ),
    );
    // null — пользователь вышел без сохранения.
    if (!mounted || newText == null) return;
    setState(() {
      note.text = newText;
    });
    _showMessage('Текст заметки обновлён');
  }

  // ===== Свайп влево: удаление (с возможностью отменить) =====
  void _deleteNote(Note note) {
    final int index = _notes.indexWhere((Note n) => n.id == note.id);
    if (index < 0) return;
    setState(() {
      _notes.removeAt(index);
    });
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: const Text('Заметка удалена'),
          action: SnackBarAction(
            label: 'Отменить',
            onPressed: () {
              if (!mounted) return;
              setState(() {
                final int pos = index > _notes.length ? _notes.length : index;
                _notes.insert(pos, note);
              });
            },
          ),
        ),
      );
  }

  /// Обработчик Dismissible. Возвращаем false: виджет не удаляет элемент сам,
  /// состоянием списка управляем вручную через setState. Так один Dismissible
  /// обрабатывает оба направления свайпа.
  Future<bool> _onSwipe(Note note, DismissDirection direction) async {
    if (direction == DismissDirection.endToStart) {
      // Для LTR-направления endToStart — это свайп ВЛЕВО → удаление.
      _deleteNote(note);
    } else {
      // startToEnd — свайп ВПРАВО → снять ⭐️.
      _resetImportant(note);
    }
    return false;
  }

  Widget _swipeBackground(
    Color color,
    Alignment alignment,
    IconData icon,
    String label,
  ) {
    return Container(
      color: color,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      alignment: alignment,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, color: Colors.white),
          const SizedBox(width: 8),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _hintChip(IconData icon, String label) {
    return Chip(
      avatar: Icon(icon, size: 16),
      label: Text(label, style: const TextStyle(fontSize: 11)),
      visualDensity: VisualDensity.compact,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
    );
  }

  /// Одна карточка заметки: Dismissible (свайпы) + GestureDetector (нажатия).
  Widget _noteCard(Note note) {
    final bool important = note.isImportant;
    return Dismissible(
      key: ValueKey<int>(note.id),
      direction: DismissDirection.horizontal,
      // background показывается при свайпе вправо (startToEnd),
      // secondaryBackground — при свайпе влево (endToStart).
      background: _swipeBackground(
        Colors.green,
        Alignment.centerLeft,
        Icons.star_border,
        'Обычный статус',
      ),
      secondaryBackground: _swipeBackground(
        Colors.red,
        Alignment.centerRight,
        Icons.delete_outline,
        'Удалить',
      ),
      confirmDismiss: (DismissDirection direction) =>
          _onSwipe(note, direction),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          _openNote(note);
        },
        onDoubleTap: () {
          _toggleImportant(note);
        },
        onLongPress: () {
          _editNote(note);
        },
        child: Card(
          color: important ? Colors.amber[100] : null,
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          elevation: important ? 4 : 1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: important
                ? const BorderSide(color: Colors.amber, width: 2)
                : BorderSide.none,
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      // В списке текст обрезается, полный — на экране просмотра.
                      Text(
                        note.text,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${_formatDate(note.createdAt)}'
                        '${important ? '   ·   ⭐️ Важная' : ''}',
                        style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                      ),
                    ],
                  ),
                ),
                if (important)
                  const Padding(
                    padding: EdgeInsets.only(left: 8),
                    child: Text('⭐️', style: TextStyle(fontSize: 24)),
                  )
                else
                  const Icon(Icons.chevron_right, color: Colors.grey),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _inputPanel() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          TextField(
            controller: _inputController,
            minLines: 1,
            maxLines: 4,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(
              labelText: 'Текст заметки',
              hintText: 'Что нужно запомнить?',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.edit),
            ),
            onSubmitted: (String value) => _addNote(),
          ),
          const SizedBox(height: 8),
          ElevatedButton.icon(
            onPressed: _addNote,
            icon: const Icon(Icons.save),
            label: const Text('Сохранить'),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 2,
            children: <Widget>[
              _hintChip(Icons.touch_app, 'Нажатие — просмотр'),
              _hintChip(Icons.star, 'Двойное — ⭐️'),
              _hintChip(Icons.timer, 'Долгое — ред.'),
              _hintChip(Icons.arrow_back, '← удалить'),
              _hintChip(Icons.arrow_forward, '→ снять ⭐️'),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Заметки'),
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(child: Text('Всего: ${_notes.length}')),
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          _inputPanel(),
          const Divider(height: 1),
          Expanded(
            child: _notes.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Заметок пока нет.\n'
                        'Введите текст и нажмите «Сохранить».',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: _notes.length,
                    itemBuilder: (BuildContext context, int index) =>
                        _noteCard(_notes[index]),
                  ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Экран просмотра полного текста (открывается по onTap)
// ─────────────────────────────────────────────────────────────────────────────
class NoteViewPage extends StatelessWidget {
  const NoteViewPage({Key? key, required this.note}) : super(key: key);

  final Note note;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Просмотр заметки')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                Chip(
                  avatar: Icon(
                    note.isImportant ? Icons.star : Icons.star_border,
                    size: 18,
                  ),
                  label: Text(note.isImportant ? '⭐️ Важная' : 'Обычная'),
                ),
                const Spacer(),
                Text(
                  _formatDate(note.createdAt),
                  style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: SingleChildScrollView(
                child: SelectableText(
                  note.text,
                  style: const TextStyle(fontSize: 18, height: 1.4),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: <Widget>[
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).pop('edit'),
                    icon: const Icon(Icons.edit),
                    label: const Text('Редактировать'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).pop('delete'),
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                    label: const Text('Удалить'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Экран редактирования (открывается по onLongPress)
// ─────────────────────────────────────────────────────────────────────────────
class EditNotePage extends StatefulWidget {
  const EditNotePage({Key? key, required this.initialText}) : super(key: key);

  final String initialText;

  @override
  State<EditNotePage> createState() => _EditNotePageState();
}

class _EditNotePageState extends State<EditNotePage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialText);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    // Возвращаем новый текст на главный экран; там setState обновит карточку.
    Navigator.of(context).pop(_controller.text.trim());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактирование заметки'),
        actions: <Widget>[
          IconButton(
            onPressed: _save,
            icon: const Icon(Icons.check),
            tooltip: 'Сохранить',
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: _controller,
                autofocus: true,
                minLines: 5,
                maxLines: 12,
                decoration: const InputDecoration(
                  labelText: 'Текст заметки',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder(),
                ),
                validator: (String? value) =>
                    (value == null || value.trim().isEmpty)
                        ? 'Текст не может быть пустым'
                        : null,
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.save),
                  label: const Text('Сохранить изменения'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
